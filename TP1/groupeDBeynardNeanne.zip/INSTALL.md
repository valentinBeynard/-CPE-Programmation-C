# Installation :

  Tous les programmes ont été compilé par la commande de compilation gcc sous Linux, à la
  racine de la source.

  **Commande de compilation :**

gcc -Wall -g my_source_name.c -o my_source_nameProg

  **Execution :**

./my_source_nameProg
