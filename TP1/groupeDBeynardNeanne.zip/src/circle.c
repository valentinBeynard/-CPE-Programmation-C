#include <stdio.h>

int main() {

	// Variables pour le calcul
	float pi = 3.14;
	float rayon = 4.0;

	// affichage des résultats
	printf("périmetre cercle : %f\n", 2*pi*rayon);
  printf("Aire du cercle : %f\n", pi*rayon*rayon);
	
	return 0;

}
