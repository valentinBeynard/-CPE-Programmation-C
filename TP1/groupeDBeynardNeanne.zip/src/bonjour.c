#include <stdio.h>

int main(){

	// Affiche bonjour.
	printf("Bonjour le monde\n");
	return 0;
}
