#Objectifs :

Ce TP est une première approche du langage C, nouveau langage pour nous. Sa visé est plutôt didactique et nous permet de maîtriser les bases indispensables au développement d'algoritmhes. Nous avons notamment traité les opérations de base arithmétiques, logiques, et les opérateurs bit à bit ( addition, soustraction… ) . Nous avons mis en oeuvre les différents types de variables natifs : chaine de caractères, entier, nombre floatant… Ce tp nous a permis aussi d’utiliser les boucles for, while, do..while, ainsi que les opérateurs conditionnels switch/case , if, else et else if. Finalement, nous avons aussi acquéri une plus grande compréhension de l'étape de compilation en observant certaines option de la commande de compilation avec gcc.

#Exercice 1 :

## Fichiers sources :

    **bonjour.c , circle.c, sizeof_type.c, variables.c, operators.c, boucles.c, boucles_while.c, boucles_do_while.c, operateurs2.c, conditions.c, conditionsB.c, conditionsC.c, binary.c**

## Bibliothèques :

  **<stdio.h>**

## Références :

  **[Cours : ](https://johnsamuel.info/fr/enseignement/cours/2018/C/cours1.html)**

## Difficulté :

  **Pas de grandes difficultées dans cette première mise en oeuvre**

## Commentaires :

  **Premier TP découverte plutôt sans surprise. Les derniers exercices manquent un peu de challenge**
